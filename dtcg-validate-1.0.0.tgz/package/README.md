# dtcg-validate

CLI tool to validate JSON (DTCG) using Ajv.

## Local usage

```bash
npx . ./tokens.json
```

## Published package

Package name in npm:

```bash
dtcg-validate
```

CLI command after install remains short:

```bash
dtcg-validate
```

Run without global install:

```bash
npx dtcg-validate ./tokens.json
```

Install globally and run:

```bash
npm install -g dtcg-validate
dtcg-validate ./tokens.json
```

## License

MIT
